﻿using Xamarin.Forms;

namespace Restaurant_Aid.Views
{
    public partial class CustomerSearchPage : ContentPage
    {
        public CustomerSearchPage()
        {
            InitializeComponent();
        }
    }
}
