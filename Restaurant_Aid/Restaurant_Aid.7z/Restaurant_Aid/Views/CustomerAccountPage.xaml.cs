﻿using Xamarin.Forms;

namespace Restaurant_Aid.Views
{
    public partial class CustomerAccountPage : ContentPage
    {
        public CustomerAccountPage()
        {
            InitializeComponent();
        }
    }
}
