﻿using Xamarin.Forms;

namespace Restaurant_Aid.Views
{
    public partial class RestaurantAccountPage : ContentPage
    {
        public RestaurantAccountPage()
        {
            InitializeComponent();
        }
    }
}
