﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Restaurant_Aid.Views
{
    public partial class RestaurantPage : ContentPage
    {
        public RestaurantPage()
        {
            InitializeComponent();
        }
    }
}
