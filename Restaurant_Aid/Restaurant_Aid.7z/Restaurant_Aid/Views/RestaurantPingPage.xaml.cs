﻿using Xamarin.Forms;

namespace Restaurant_Aid.Views
{
    public partial class RestaurantPingPage : ContentPage
    {
        public RestaurantPingPage()
        {
            InitializeComponent();
        }
    }
}
